# SRDC Website — GitHub Pages

芝浦工業大学ロボット開発サークル SRDC の公式ウェブサイトです。

## 📁 ファイル構成

```
srdc-website/
├── index.html          ← メインページ（ここを編集）
├── assets/
│   ├── css/
│   │   └── style.css   ← スタイル（デザイン変更はここ）
│   ├── js/
│   │   └── main.js     ← AIチャットボット＋アニメーション
│   └── images/         ← 写真をここに入れる
└── README.md
```

## 🚀 GitHub Pages での公開手順

1. このフォルダを GitHub の新しいリポジトリにプッシュ
   ```bash
   git init
   git add .
   git commit -m "first commit"
   git branch -M main
   git remote add origin https://github.com/ユーザー名/srdc-website.git
   git push -u origin main
   ```

2. GitHub の Settings → Pages → Source を `main` ブランチに設定

3. `https://ユーザー名.github.io/srdc-website/` で公開されます！

---

## 📸 写真の差し替え方

### ステップ1: 写真を `assets/images/` に入れる
例: `assets/images/hero.jpg`, `assets/images/kawasaki.jpg` など

### ステップ2: `index.html` の上部 `<style>` ブロックを書き換える

```css
:root {
  --hero-img:       url('assets/images/hero.jpg');       /* ヒーロー背景 */
  --about-main-img: url('assets/images/about-main.jpg'); /* Aboutメイン */
  --about-sub-img:  url('assets/images/about-sub.jpg');  /* Aboutサブ */
  --blog-main-img:  url('assets/images/blog-main.jpg');  /* ブログメイン */
}
```

### ステップ3: 各ロボットカードの写真を変更する
`index.html` の中で `📸` コメントがついている行を探して、
`background-image: url('...')` のURLを変えるだけです。

---

## 🤖 AIチャットボットについて

右下のロボットアイコンをクリックすると、新入生向けQ&AのAIチャットボットが起動します。

### 動作させるには
`assets/js/main.js` の `BOT_SYSTEM_PROMPT` にサークルの情報を追加・編集してください。
APIキーは Claude.ai / Anthropic の仕組みで自動処理されます。

---

## 📝 よくある変更箇所

| 変更したいもの | 場所 |
|---|---|
| ヒーローの写真 | `index.html` の `--hero-img` |
| キャッチコピー | `index.html` の `<h1>` |
| 部員数・活動日数 | `index.html` の `.hero-stat-num` |
| SNSリンク | `index.html` の footer の `href="#"` |
| 仮入部フォームURL | `index.html` の `btn-red` の `href="#"` |
| アクセントカラー | `style.css` の `--accent: #e63225;` |
| チャットボットの回答 | `main.js` の `BOT_SYSTEM_PROMPT` |
